Solomon Mori


I selected HTML 5 due to it's access to more semantic tags and it's stricter rules on presentational markup than HTML 4. XHTML remains stricter and simpler in terms of doctype complexity than HTML 5, but HTML5's tags won out for me.


I used div to signify nested elements and to show that the parts constitute an entity; I could not find a more appropriate tag to for those purposes. Though p and ul wouldve been prefered, they do not allow for nested tags, however I did use them when I could to signify text and related elements constituting an entity respectively. I used span for the microformat related entites since I intended no semantic meaning beyond that of the class titles required. Article was the most appropriate since all the elements under it constituted an object intended to be consumed together and I used header to further semantically seperate content in the article. 

I'm not sure of the ways machines or human users currently take advantage of hCard formatting but I can certainly imagine a bunch of different ways it can be used. If you're a human and you visit the site, imagine if there was an option to download the hcard, if youre on your phone save it as a contact right from the page, or if youre on a computer to add the info to your email client. From a machine perspective, web crawlers can certainly make use of the info, if a search engine pulls up a organization or an individual and finds an hcard maybe it can present it as an hcard in the results before you click it. Or imagine automated address books, where each entity points to a permanent hcard that periodically refereshes and updates if there are any changes. No more mass texts to my contacts just to share my new number/address! 

References:

http://www.w3schools.com/tags/tag_doctype.asp
http://www.w3schools.com/html/html_xhtml.asp
http://www.w3schools.com/tags/ref_html_dtd.asp
http://www.w3schools.com/tags/tag_header.asp
https://www.google.com/search?q=Start+tag+body+seen+but+an+element+of+the+same+type+was+already+open.&oq=Start+tag+body+seen+but+an+element+of+the+same+type+was+already+open.&aqs=chrome..69i57j0l2.568j0j7&sourceid=chrome&es_sm=93&ie=UTF-8
http://www.smashingmagazine.com/2011/07/learning-to-use-the-before-and-after-pseudo-elements-in-css/
http://www.w3schools.com/css/css3_multiple_columns.asp
http://microformats.org/get-started