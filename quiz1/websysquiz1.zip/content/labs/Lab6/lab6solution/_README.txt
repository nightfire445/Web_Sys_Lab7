All of my changes improve HCI simply by delivering the page faster. The most common issue with a users expereince is excessive length in operations. Thus optimize where possible, provide feedback for lengthy operations that cannot be improved so that the user understands that their action was interpreted.

See the html page for inline comments on improvements.